<?php $__env->startSection('ben'); ?>



    <?php echo Form::open(array('route'=>['task.update',$abc->id],'method'=>'patch')); ?>

    <div class="form-group <?php echo $errors->has('name')? "has-error":""; ?>">
        <?php echo Form::label('title','Name of Task:'); ?>

        <?php echo Form::text('name',$abc->name,['class'=>'form-control']); ?>

        <?php echo $errors->first('name','<span class="help-block">:message</span>'); ?>

    </div>
    <div class="form-group <?php echo $errors->has('description')? "has-error":""; ?>">
        <?php echo Form::label('desc','Description:'); ?>

        <?php echo Form::textarea('description',$abc->description,['class'=>'form-control']); ?>

        <?php echo $errors->first('description','<span class="help-block">:message</span>'); ?>


    </div>
    <div class="form-group ">
        <div class="col-md-4 move">
            <?php echo Form::submit('Update Task',['class'=>'form-control col-md-offset-12 btn btn-primary btn-block']); ?>

        </div>
        <?php echo Form::close(); ?>


    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>