<?php $__env->startSection('ben'); ?>


 <div class="panel panel-info">
  <div class="panel-heading">
   <h3 class="panel-title"> <?php echo e($abc->name); ?></h3>
  </div>
  <div class="panel-body">
   <?php echo e($abc->description); ?>

  </div>
 </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>