<?php $__env->startSection('ben'); ?>



 <?php echo Form::open(array('route'=>'contact.store')); ?>

 <div class="form-group <?php echo $errors->has('name')? "has-error":""; ?>">
 <?php echo Form::label('title','Contact Name:'); ?>

 <?php echo Form::text('name',null,['class'=>'form-control']); ?>

  <?php echo $errors->first('name','<span class="help-block">:message</span>'); ?>

     </div>

     <!-- email -->
     <div class="form-group <?php echo $errors->has('email')? "has-error":""; ?>">
 <?php echo Form::label('title','Enter Contact Email:'); ?>

 <?php echo Form::text('email',null,['class'=>'form-control']); ?>

  <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

     </div>

     <!-- phoneNumber -->
     <div class="form-group <?php echo $errors->has('pnum')? "has-error":""; ?>">
 <?php echo Form::label('title','Enter Contact Number:'); ?>

 <?php echo Form::text('pnum',null,['class'=>'form-control']); ?>

  <?php echo $errors->first('pnum','<span class="help-block">:message</span>'); ?>

     </div>

     <!-- address -->
     <div class="form-group <?php echo $errors->has('address')? "has-error":""; ?>">
 <?php echo Form::label('title','Enter Contact Address:'); ?>

 <?php echo Form::text('address',null,['class'=>'form-control']); ?>

  <?php echo $errors->first('address','<span class="help-block">:message</span>'); ?>

     </div>
     <!-- <div class="form-group <?php echo $errors->has('description')? "has-error":""; ?>">
 <?php echo Form::label('desc','Description:'); ?>

 <?php echo Form::textarea('description',null,['class'=>'form-control']); ?>

         <?php echo $errors->first('description','<span class="help-block">:message</span>'); ?>

     </div> -->
         <div class="form-group ">
    <div class="col-md-4 move">
 <?php echo Form::submit('Update Contacts',['class'=>'form-control col-md-offset-12 btn btn-success btn-block']); ?>

    </div>
        <?php echo Form::close(); ?>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>