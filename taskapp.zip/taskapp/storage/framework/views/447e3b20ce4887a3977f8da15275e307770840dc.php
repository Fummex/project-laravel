<?php $__env->startSection('ben'); ?>
    <?php if(Session::has('msg_success')): ?>
    <div class="alert alert-success"><?php echo e(Session('msg_success')); ?></div>
    <?php endif; ?>
    <?php if(Session::has('msg_danger')): ?>
        <div class="alert alert-danger"><?php echo e(Session('msg_danger')); ?></div>
    <?php endif; ?>
    <?php if(Session::has('msg_update')): ?>
        <div class="alert alert-info"><?php echo e(Session('msg_update')); ?></div>
    <?php endif; ?>
    <table class="table table-responsive table-bordered table-striped">
        <thead>
        <th>Name:</th>
        <th>Description:</th>
        <th>Preview:</th>
        <th>Edit:</th>
        <th>Delete:</th>
        </thead>
        <tbody>
        <?php foreach($tasks as $task): ?>
            <tr>
                <td><a href="<?php echo e(route('task.show',$task->id)); ?>"><?php echo e($task->name); ?></a></td>
                <td><?php echo e($task->description); ?></td>
                <td>
                    <?php if(Auth::user()->id == $task->user_id): ?>
                    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#prev">
                        Preview
                    </button></td>
                <?php elseif(!Auth::user()->id == $task->user_id): ?>
                    <span class="btn btn-danger fa fa-eye-slash"> Sorry Bro</span>
                <?php endif; ?>
                <td><a href="<?php echo e(url('task/'.$task->id.'/edit')); ?>" class="btn btn-warning"><span class="fa fa-edit"></span></a></td>
                <td>
                <?php echo Form::open(array('route'=>['task.destroy',$task->id],'method'=>'delete')); ?>

                <input type="submit" value="Delete" class="btn btn-danger fa fa-trash" />
           <?php echo Form::close(); ?>

                </td>

                <div class="modal fade" tabindex="-1" role="dialog" id="prev">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title"><?php echo e($task->name); ?></h4>
                            </div>
                            <div class="modal-body">
                                <p><?php echo e($task->created_at->diffForHumans()); ?>&hellip;</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary">Save changes</button>
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </tr>
        <?php endforeach; ?>
        </tbody>

    </table>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>