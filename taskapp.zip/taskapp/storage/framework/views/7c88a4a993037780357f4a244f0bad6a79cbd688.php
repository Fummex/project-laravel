<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <?php if(Auth::user()): ?>
            <a class="navbar-brand" href="#"><?php echo e(Auth::user()->name); ?></a>
                <?php endif; ?>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active"><a href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a></li>


                <?php if(!Auth::user()): ?>
                <!-- <li class="pull-right"><a href="<?php echo e(url('/register')); ?>">Contacts</a></li> -->
                <li class="pull-right"><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                <li class="pull-right"><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                <?php endif; ?>
                <?php if(Auth::user()): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Tasks <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('task.create')); ?>">Add Task</a></li>
                            <li><a href="<?php echo e(route('task.index')); ?>">All Tasks</a></li>
                            <!-- <li><a href="#">Add Contact</a></li> -->

                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('contact.create')); ?>">Add Contact</a></li>
                            <li><a href="<?php echo e(route('contact.index')); ?>">All Contacts</a></li>
                            <!-- <li><a href="#">Add Contact</a></li> -->
                        </ul>
                    </li>
                    <li class="pull-right"><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                    <?php endif; ?>
            </ul>

        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>