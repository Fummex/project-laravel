<!DOCTYPE html>
<html>
<head>
    <title>Our App</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/font-awesome.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/own.css')); ?>" />
</head>
<body>
<div class="container-fluid col-md-10 col-md-offset-1">
    <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-md-8 col-md-offset-2">

        <?php echo $__env->yieldContent('ben'); ?>
    </div>
</div>




</body>
<script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>

<script src="<?php echo e(URL::asset('js/bootstrap.js')); ?>"></script>


</html>