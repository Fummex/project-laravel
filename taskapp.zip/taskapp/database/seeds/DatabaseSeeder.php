<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        App\User::truncate();
        App\Contact::truncate();
        factory(App\User::class,1)->create(['email'=>'me@u.me','name'=>'me','password'=>'password'])->each(function($user){
        	factory(App\Contact::class,50)->create(['user_id'=>$user->id]);
        });
    }
}
