<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Contact extends Model
{
    //

    /**
     */
    Use SoftDeletes;


    protected $table = 'contact';
    protected $fillable =['name','email','pnum','address'];
    //defining relationships

    public function User(){
        return $this->belongsTo('\App\User');
    }
}
