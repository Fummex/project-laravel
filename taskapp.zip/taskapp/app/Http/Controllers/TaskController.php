<?php

namespace App\Http\Controllers;

use App\Task;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //show all tasks
        $tasks = Task::all();
        return view('all',compact('tasks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //this is responsible for the addition of tasks
        return view('add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Requests\AddTaskRequest $request)
    {
        //
//        dd($request->all());
        //        $object->name=$request->name;
//        $object->description=$request->description;
        //The above is still transcient(In memory/ram)
        //About to persist
//        $object->save();
        $object = new Task($request->all());
        $object->save();
        $object->user_id = Auth::user()->id;
        $object->update();
        Session::flash('msg_success','New Task Added Sucessfully');
        return redirect(route('task.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $abc = Task::find($id);
        return view('single',compact('abc'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $abc = Task::find($id);
        return view('edit',compact('abc'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Requests\AddTaskRequest $request, $id)
    {
        //
        $upt = Task::find($id);
        $upt->update($request->all());
        Session::flash('msg_update','Task Updated Sucessfully');
        return redirect(route('task.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //about deleting the task
        $task = Task::find($id);
        $task->delete();
        Session::flash('msg_danger','Message Deleted Sucessfully');
        return redirect(route('task.index'));
    }
}
