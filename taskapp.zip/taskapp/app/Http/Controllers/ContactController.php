<?php

namespace App\Http\Controllers;

//use App\contact;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Contact;

class ContactController extends Controller
{
    //
    //@return /*\Illuminate\Http\Response*/
    public function index()
    {
        //show all contacts
        $contacts = Contact::all();
        return view('allCont',['contacts'=>$contacts]);
        //return view('allCont');
    }

    public function create(){
    	return view('addCont');
    }

    public function store(Requests\AddContRequest $request){
    	/*return \Redirect::route('contact')
      ->with('message', 'Thanks Adding!');*/
      $object = new Contact($request->all());
        $object->save();
        $object->user_id = Auth::user()->id;
        $object->update();
        Session::flash('msg_success','New Contact Added Sucessfully');
        return redirect(route('contact.index'));
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $abc = Contact::find($id);
        return view('people',compact('abc'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $abc = Contact::find($id);
        return view('editCont',compact('abc'));
    }
}
