@extends('welcome')

@section('ben')
    @if(Session::has('msg_success'))
    <div class="alert alert-success">{{Session('msg_success')}}</div>
    @endif
    @if(Session::has('msg_danger'))
        <div class="alert alert-danger">{{Session('msg_danger')}}</div>
    @endif
    @if(Session::has('msg_update'))
        <div class="alert alert-info">{{Session('msg_update')}}</div>
    @endif
    <table class="table table-responsive table-bordered table-striped">
        <thead>
        <th>Name:</th>
        <!-- <th>Lastname</th> -->
        <th>Phone number:</th>
        <th>Preview:</th>
        <th>Edit:</th>
        <th>Delete:</th>
        </thead>
        <tbody>
        @foreach($contacts as $contact)
            <tr>
                
                <td><a href="{{route('contact.show',$contact->id)}}">{{$contact->name}}</a></td>
                <td>{{$contact->pnum}}</td>
                <td>
                    @if(Auth::user()->id == $contact->user_id)
                    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#prev">
                        Preview
                    </button></td>
                @elseif(!Auth::user()->id == $contact->user_id)
                    <span class="btn btn-danger fa fa-eye-slash"> Sorry Bro</span>
                @endif
                <td><a href="{{url('contact/'.$contact->id.'/edit')}}" class="btn btn-warning"><span class="fa fa-edit"></span></a></td>
                <td>
                {!! Form::open(array('route'=>['contact.destroy',$contact->id],'method'=>'delete'))!!}
                <input type="submit" value="Delete" class="btn btn-danger fa fa-trash" />
           {!! Form::close() !!}
                </td>

                <div class="modal fade" tabindex="-1" role="dialog" id="prev">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">{{$contact->name}}</h4>
                            </div>
                            <div class="modal-body">
                                <p>{{$contact->created_at->diffForHumans()}}&hellip;</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary">Save changes</button>
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </tr>
        @endforeach
        </tbody>

    </table>





@endsection