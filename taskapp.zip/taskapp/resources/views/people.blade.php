@extends('welcome')

@section('ben')


 <div class="panel panel-info">
  <div class="panel-heading">
   <h3 class="panel-title"> {{$abc->name}}</h3>
  </div>
  <div class="panel-body">
   {{$abc->description}}
  </div>
 </div>





@endsection