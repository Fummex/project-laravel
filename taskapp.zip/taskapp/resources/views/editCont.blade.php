@extends('welcome')

@section('ben')



 {!! Form::open(array('route'=>'contact.store')) !!}
 <div class="form-group {!! $errors->has('name')? "has-error":"" !!}">
 {!! Form::label('title','Contact Name:') !!}
 {!! Form::text('name',null,['class'=>'form-control']) !!}
  {!! $errors->first('name','<span class="help-block">:message</span>') !!}
     </div>

     <!-- email -->
     <div class="form-group {!! $errors->has('email')? "has-error":"" !!}">
 {!! Form::label('title','Enter Contact Email:') !!}
 {!! Form::text('email',null,['class'=>'form-control']) !!}
  {!! $errors->first('email','<span class="help-block">:message</span>') !!}
     </div>

     <!-- phoneNumber -->
     <div class="form-group {!! $errors->has('pnum')? "has-error":"" !!}">
 {!! Form::label('title','Enter Contact Number:') !!}
 {!! Form::text('pnum',null,['class'=>'form-control']) !!}
  {!! $errors->first('pnum','<span class="help-block">:message</span>') !!}
     </div>

     <!-- address -->
     <div class="form-group {!! $errors->has('address')? "has-error":"" !!}">
 {!! Form::label('title','Enter Contact Address:') !!}
 {!! Form::text('address',null,['class'=>'form-control']) !!}
  {!! $errors->first('address','<span class="help-block">:message</span>') !!}
     </div>
     <!-- <div class="form-group {!! $errors->has('description')? "has-error":"" !!}">
 {!! Form::label('desc','Description:') !!}
 {!! Form::textarea('description',null,['class'=>'form-control']) !!}
         {!! $errors->first('description','<span class="help-block">:message</span>') !!}
     </div> -->
         <div class="form-group ">
    <div class="col-md-4 move">
 {!! Form::submit('Update Contacts',['class'=>'form-control col-md-offset-12 btn btn-success btn-block']) !!}
    </div>
        {!! Form::close() !!}

</div>



@endsection