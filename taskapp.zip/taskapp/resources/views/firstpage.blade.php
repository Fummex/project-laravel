@extends('welcome')

@section('ben')


    <div class="jumbotron">
        <h1>Hello, there!</h1>
        <p>Welcome to our tasks app</p>
        <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a></p>
    </div>




@endsection