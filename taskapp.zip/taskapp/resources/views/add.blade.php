@extends('welcome')

@section('ben')



 {!! Form::open(array('route'=>'task.store')) !!}
 <div class="form-group {!! $errors->has('name')? "has-error":"" !!}">
 {!! Form::label('title','Contact Name:') !!}
 {!! Form::text('name',null,['class'=>'form-control']) !!}
  {!! $errors->first('name','<span class="help-block">:message</span>') !!}
     </div>
     <div class="form-group {!! $errors->has('description')? "has-error":"" !!}">
 {!! Form::label('desc','Description:') !!}
 {!! Form::textarea('description',null,['class'=>'form-control']) !!}
         {!! $errors->first('description','<span class="help-block">:message</span>') !!}

     </div>
         <div class="form-group ">
    <div class="col-md-4 move">
 {!! Form::submit('Add Task',['class'=>'form-control col-md-offset-12 btn btn-primary btn-block']) !!}
    </div>
        {!! Form::close() !!}

</div>



@endsection