<!DOCTYPE html>
<html>
<head>
    <title>Our App</title>
    <link rel="stylesheet" href="{{URL::asset('css/bootstrap.css')}}" />
    <link rel="stylesheet" href="{{URL::asset('css/font-awesome.css')}}" />
    <link rel="stylesheet" href="{{URL::asset('css/own.css')}}" />
</head>
<body>
<div class="container-fluid col-md-10 col-md-offset-1">
    @include('partials.navbar')
    <div class="col-md-8 col-md-offset-2">

        @yield('ben')
    </div>
</div>




</body>
<script src="{{URL::asset('js/jquery.js')}}"></script>

<script src="{{URL::asset('js/bootstrap.js')}}"></script>


</html>