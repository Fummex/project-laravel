<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">

<!-- <div class="example"> -->
    <ul id="nav">
        <!-- <li class="current"><a href="#">Home</a></li> -->
        <li><a href="index.html">Home</a></li>
        
        <li><a href="about.html">About</a></li>
        <li><a href="contact.html">Contacts</a></li>
        <!-- <li><a href="#">Hobbies and Interest</a></li> -->
    </ul>
    <br><br><br><br><br><br><br>

    <center><h1>About Me</h1><br><br>
    <div>
    <h2>Personal Details</h2>
    	<p>My name is Oladunjoye Oluwafunmilayo Racheal</p>
    	<p>I am an Information Technology Student of Valley View University</p>
    </div>

    <div>
    	<h2>Contact Details</h2>
    	<p>
    	<label>Email:</label>
    	fumex456@gmail.com
    	</p>

    	<p>
    		<label>Contact number:</label>
    		0277455051
    	</p>

    	<p>
    		<label>facebook id:</label>
    		oladunjoye oluwfunmilayo
    	</p>

    	<p>
    		<label>Instagram id:</label>
    		@ms_oor
    	</p>
    </div>
    </center>
