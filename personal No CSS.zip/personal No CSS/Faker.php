
<!DOCTYPE html>
<html>
<head>
	<title>Faker</title>
	<!-- <link rel="stylesheet" type="text/css" href="style2.css"> -->
</head>
<body>
<form>
	
<fieldset>
 <h1>
       <strong> Contact Details</strong>
</h1>

     <label>
     	<span>
     		<?php

// require the Faker autoloader
require_once 'vendor/autoload.php';

// use the factory to create a Faker\Generator instance
$faker = Faker\Factory::create();


// generate data by accessing properties
for ($i=0; $i <10000 ; $i++)
{ 
	//Data to be Displayed
	echo "<img src= '$faker->image' width = '150px' height = '150px'><br>";
	echo "<b>Full Name : </b>". $faker->name."</br>";
	echo "<b>Number : </b>". $faker->phoneNumber."</br>";
	echo "<b>Address : </b>". $faker->address."</br>";
	echo "<b>Occupation : </b>". $faker->occupation."</br>";
	echo "<b>Gender : </b>". $faker->gender."</br>";
	echo "<b>Email : </b>". $faker->email."</br>";
	echo "<b>Country : </b>". $faker->country."</br>";
	echo "<b>City : </b>". $faker->city."</br>";
	echo "<b>Text : </b>". $faker->realText. "<hr></br><br>" ;
} 
?>
     	</span>
     </label>



</fieldset>
</form>
</body>
</html>