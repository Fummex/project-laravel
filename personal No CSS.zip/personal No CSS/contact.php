<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;border-color:#aaa;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#aaa;color:#333;background-color:#fff;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#eee;color:#fff;background-color:#f38630;}
.tg .tg-yw4l{vertical-align:top}
</style>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">

<!-- <div class="example"> -->
    <ul id="nav">
        <!-- <li class="current"><a href="#">Home</a></li> -->
        <li><a href="index.html">Home</a></li>
        
        <li><a href="about.html">About</a></li>
        <li><a href="contact.html">Contacts</a></li>
        <!-- <li><a href="#">Hobbies and Interest</a></li> -->
    </ul>
<center>
<br><br><br><br><br><br>
<div id="wrap">
		<h1>Drop your Message!</h1>
		<div id='form_wrap'>
			<form id="contact-form" action="javascript:alert('success!');">

		<p id="formstatus"></p>
				<p>Hello Friend,</p>
				<label for="email">Your Message : </label>
				<textarea  name="message" value="Your Message" id="message" ></textarea>
				<p>Best,</p>	
				<label for="name">Name: </label>
				<input type="text" name="name" value="" id="name" />
				<label for="email">Email: </label>
				<input type="text" name="email" value="" id="email" />
				<input type="submit" name ="submit" value="Send Message, thanks!" />
			</form>
		</div>
	</div>
<table class="tg">
  <thead class="tg-yw4l">
        	<th>Firstname:</th>
        	<th>Lastname:</th>
        	<th>Contacts:</th>
        	<th>Message:</th>
        </thead>

        <tbody>
        	<tr>
        		<td>joy</td>
        		<td>ama</td>
        		<td>020745609</td>
        		<td>where are you</td>
        	</tr>
        	<tr>
        		<td>kane</td>
        		<td>josh</td>
        		<td>027552890390</td>
        		<td>whats up</td>
        	</tr>
        	<tr>
        		<td>corn</td>
        		<td>saint</td>
        		<td>07277656265</td>
        		<td>coming over</td>
        	</tr>
        	<tr>
        		<td>Will</td>
        		<td>Smith</td>
        		<td>0977365652676</td>
        		<td>what's good</td>
        	</tr>
        	<tr>
        		<td></td>
        	</tr>
        </tbody>
</table></center>