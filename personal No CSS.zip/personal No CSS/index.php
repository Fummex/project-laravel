<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">

<!-- <div class="example"> -->
    <ul id="nav">
        <!-- <li class="current"><a href="#">Home</a></li> -->
        <li><a href="index.html">Home</a></li>
        
        <li><a href="about.html">About</a></li>
        <li><a href="contact.html">Contacts</a></li>
        <li><a href="Faker.php">Friends</a></li>
        <!-- <li><a href="#">Hobbies and Interest</a></li> -->
    </ul>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    <left><h1>Welcome to MY Personal Site</h1></left>
